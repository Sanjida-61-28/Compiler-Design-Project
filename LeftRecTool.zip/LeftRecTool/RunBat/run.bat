@echo off
chcp 65001 >nul

echo ===== DEFAULT MODE: valid and invalid programs =====
for %%f in (tests\valid*.txt tests\invalid*.txt) do (
    echo.
    echo ----- %%f
    python main.py %%f
)

echo.
echo ===== -lr MODE: valid programs =====
for %%f in (tests\valid*.txt) do (
    echo.
    echo ----- %%f
    python main.py %%f -lr
)

echo.
echo ===== -opt MODE: optimization =====
python main.py tests\optim.txt -opt
