# Left Recursion and Left Factoring Tool

Compiler Design project  

A small command-line compiler for a tiny language: a text format for context-free grammars (CFGs). It reads a grammar from a file, checks it for ambiguity, and prints a grammar that is suitable for top-down parsing (no ambiguity, no left recursion, left-factored).

## What it does

1. **Lexer, parser and semantic checks** read the grammar and report lexical, syntax and semantic errors with clear messages.
2. **Optimization** removes duplicate alternatives (`A -> a | a | b` becomes `A -> a | b`).
3. **Ambiguity check.**
   - Not ambiguous: prints `Not Ambiguous` and nothing else.
   - Ambiguous: makes the grammar unambiguous (operator precedence, dangling else), removes left recursion with the two standard rules (`A -> b A'` and `A' -> a A' | ε`), applies left factoring, and prints the final grammar.
4. **Bonus:** indirect left recursion is removed too (`A -> B a`, `B -> A b`).

## Requirements

- Python 3.8 or newer
- PLY (Python Lex-Yacc): `pip install ply`

No build step is needed.

## How to run

```
python main.py <grammar-file> [options]
```

| Option | What it does |
|---|---|
| (none) | Default mode: check ambiguity first, then transform |
| `-lr` | Skip the ambiguity check; only remove left recursion and apply left factoring |
| `-opt` | Only run the optimization (remove duplicate alternatives) |
| `-tokens` | Print the token stream |
| `-symtab` | Print the symbol table |
| `-len N` | Longest string used by the ambiguity check (default 9) |

On Windows PowerShell, run this once first so that the symbol `ε` prints correctly:

```
[Console]::OutputEncoding = [Text.Encoding]::UTF8
```

## Input format

One rule per line, symbols separated by spaces:

```
E -> E + T | T
S -> i E t S | i E t S e S | a
```

- A name starting with a capital letter is a nonterminal (`E`, `T1`, `E'`). Everything else (`id`, `+`, `(`) is a terminal.
- `ε` is the empty string. Save grammar files as UTF-8.

## Example 1: an ambiguous grammar

Command:

```
python main.py tests/valid2.txt
```

Input (`tests/valid2.txt`):

```
E -> E + E | id
```

Output:

```
Grammar is AMBIGUOUS.

Original grammar:
E -> E + E | id

Step 1 - Remove ambiguity (precedence / matched-unmatched rule):
E -> E + T | T
T -> id

Step 2 - Remove left recursion (found in: E)
  Rule 1: A -> A a | b   becomes   A -> b A'
  Rule 2:                          A' -> a A' | ε
E -> T E'
E' -> + T E' | ε
T -> id

Final unambiguous grammar:
E -> T E'
E' -> + T E' | ε
T -> id
```

## Example 2: a grammar that is not ambiguous

```
python main.py tests/valid4.txt
```

```
Not Ambiguous
```

## Example 3: left recursion and left factoring only (`-lr`)

Command:

```
python main.py tests/valid1.txt -lr
```

Input (`tests/valid1.txt`):

```
E -> E + T | T
S -> i E t S | i E t S e S | a
```

Output:

```
E -> T E'
E' -> + T E' | ε
S -> i E t S S' | a
S' -> e S | ε
```

A warning that `T` has no rule is printed first; it is expected for this input.

## Error messages

| Type | Command | Output |
|---|---|---|
| Lexical | `python main.py tests/invalid_lexical.txt` | `Lexical error at line 2: illegal character '@'` |
| Syntax | `python main.py tests/invalid_syntax.txt` | `Syntax error at line 2: unexpected 'F'` |
| Semantic | `python main.py tests/invalid_semantic.txt` | `Semantic error: 'E' has only left-recursive alternatives (no base case)` |

## Test programs

The `tests` folder has five correct programs and three programs with errors:

| File | Purpose | Result |
|---|---|---|
| `valid1.txt` | Project sample (dangling else, left recursion) | Ambiguous |
| `valid2.txt` | One operator | Ambiguous |
| `valid3.txt` | Two operators and brackets | Ambiguous |
| `valid4.txt` | Expression grammar | Not Ambiguous |
| `valid5.txt` | Indirect left recursion and nested left factoring | Not Ambiguous |
| `invalid_lexical.txt` | Illegal character | Lexical error |
| `invalid_syntax.txt` | Rule without an arrow | Syntax error |
| `invalid_semantic.txt` | No base case | Semantic error |
| `optim.txt` (extra) | Duplicate alternatives | Use `-opt` |

Run all tests at once with `run.bat` (Windows). Use `-lr` to see left recursion and left factoring on the `valid` files, for example `python main.py tests/valid5.txt -lr`.

## Project files

| File | Phase |
|---|---|
| `main.py` | Command-line driver |
| `lexer.py` | Lexer (token list) |
| `parser.py` | Parser (builds the grammar) |
| `semantic.py` | Symbol table and semantic checks |
| `ambiguity.py` | Ambiguity check and ambiguity removal |
| `transform.py` | Left recursion removal, left factoring, optimization, printing |
| `run.bat` | Runs all test programs |


## Team

| Name | ID | Phase |
|---|---|---|
| [Labiba Mahajabin] | [666-61-08] | Lexer and parser |
| [Sanjida Ali] | [666-61-28] | Left recursion removal, left factoring, optimization |
| [Tamimul Jannat] | [666-61-35] | Symbol table, semantic checks, ambiguity analysis|
